/*
 * package com.empapp.config;
 * 
 * import org.springframework.web.bind.annotation.GetMapping; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RestController;
 * 
 * @RestController public class Snippet {
 * 
 * @GetMapping(produces = "application/json")
 * 
 * @RequestMapping({ "/validateLogin" }) public AuthResponse validateLogin() {
 * return new AuthResponse("User successfully authenticated"); } }
 */
